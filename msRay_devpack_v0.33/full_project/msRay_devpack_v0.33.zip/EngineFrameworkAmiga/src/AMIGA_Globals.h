#define GLOBAL_NAME                 "msRay (v0.33)"
#define GLOBAL_DATE                 "2022"

#define GLOBAL_STA_WIN_NAME         GLOBAL_NAME", Amiga Starter."
#define GLOBAL_FRM_IN_CONSOLE_NAME  GLOBAL_NAME", Amiga Framework\nby Mateusz Staniszew, "GLOBAL_DATE"."

#define GLOBAL_OUTPUT_FILENAME      "data/frm060.exe"